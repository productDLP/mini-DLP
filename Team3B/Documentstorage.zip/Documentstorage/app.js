import express from 'express';

const app = express();
const PORT = 3000;


app.use(express.json());


let documents = [];
let currentId = 1;


app.get('/', (req, res) => {
    res.send('Welcome to the Document Management API!');
});


app.post('/api/documents', (req, res) => {
    const { title, content } = req.body;
    if (!title || !content) {
        return res.status(400).json({ error: 'Title and content are required.' });
    }
    const newDocument = {
        id: currentId++,
        title,
        content,
        createdAt: new Date().toISOString(),
    };
    documents.push(newDocument);
    res.status(201).json({ message: 'Document created.', document: newDocument });
});


app.get('/api/documents', (req, res) => {
    res.json({ documents });
});


app.get('/api/documents/:docId', (req, res) => {
    const docId = parseInt(req.params.docId, 10);
    const document = documents.find((doc) => doc.id === docId);
    if (!document) {
        return res.status(404).json({ error: 'Document not found.' });
    }
    res.json({ document });
});


app.put('/api/documents/:docId', (req, res) => {
    const docId = parseInt(req.params.docId, 10);
    const { title, content } = req.body;
    const documentIndex = documents.findIndex((doc) => doc.id === docId);
    if (documentIndex === -1) {
        return res.status(404).json({ error: 'Document not found.' });
    }
    if (!title || !content) {
        return res.status(400).json({ error: 'Title and content are required.' });
    }
    documents[documentIndex] = {
        ...documents[documentIndex],
        title,
        content,
        updatedAt: new Date().toISOString(),
    };
    res.json({ message: 'Document updated.', document: documents[documentIndex] });
});


app.delete('/api/documents/:docId', (req, res) => {
    const docId = parseInt(req.params.docId, 10);
    const documentIndex = documents.findIndex((doc) => doc.id === docId);
    if (documentIndex === -1) {
        return res.status(404).json({ error: 'Document not found.' });
    }
    const deletedDocument = documents.splice(documentIndex, 1);
    res.json({ message: 'Document deleted.', document: deletedDocument });
});


app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
